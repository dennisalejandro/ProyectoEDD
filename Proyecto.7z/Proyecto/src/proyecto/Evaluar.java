/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

/**
 *
 * @author denni
 */
public class Evaluar {
    public int Calcular(String In) {
        int total = 0;
        In+="+";
        String number = "";
        for (int i  = 1;i<In.length();i++) {
            if (isDigit(In.charAt(i))) {
                number+= In.charAt(i);
            } else {
                //System.out.println(number);
                //System.out.println("op: "+In.charAt(i-number.length()-1));
                int b = Integer.parseInt(number);
                switch(In.charAt(i-number.length()-1)) {
                    case '+':
                        total += b;
                            break;
                    case '-':
                        total -= b;
                            break;
                    case '*':
                        total *= b;
                            break;
                    case '/':
                        total /= b;
                }
                number = "";
            }
            //System.out.println("total: "+total);
        }
        return total;
    }
    public String MD(String Input) {
        String NewString = Input;
        return NewString;
    }
    boolean isDigit(char a) {
        switch (a){
            case '1':
                return true;
            case '2':
                return true;
            case '3':
                return true;
            case '4':
                return true;
            case '5':
                return true;
            case '6':
                return true;
            case '7':
                return true;
            case '8':
                return true;
            case '9':
                return true;
            case '0':
                return true;
            default:
                return false;
        }
    }
}
