/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author denni
 */
public class Proyecto {
    static String word;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //File Archivo = new File("Maze.txt");
        Frame f = new Frame();
        f.setVisible(true);
        /*word = "";
        word+=lol(73);
        word+=lol(32);
        word+=lol(100);
        word+=lol(111);
        word+=lol(110);
        word+=lol(39);
        word+=lol(116);
        
        word+=lol(32);
        word+=lol(100);
        word+=lol(101);
        word+=lol(115);
        word+=lol(101);
        word+=lol(114);
        word+=lol(118);
        word+=lol(101);
        word+=lol(32);
        word+=lol(116);
        
        word+=lol(111);
        word+=lol(32);
        word+=lol(112);
        word+=lol(97);
        word+=lol(115);
        word+=lol(115);
        word+=lol(32);
        word+=lol(116);
        word+=lol(104);
        word+=lol(105);
        
        word+=lol(115);
        word+=lol(32);
        word+=lol(99);
        word+=lol(108);
        word+=lol(97);
        word+=lol(115);
        word+=lol(115);
        word+=lol(46);
        word+=lol(10);
        word+=lol(0);
        
        System.out.println(word);
        */
        
    }
    public static char lol(int ascii) {
        char a = (char)ascii;
        return a;
    }
    
}
