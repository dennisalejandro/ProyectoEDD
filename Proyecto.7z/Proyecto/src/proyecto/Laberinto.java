/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Stack;

/**
 *
 * @author denni
 */
public class Laberinto {

    /*
    Index:
    Nothing = 0
    Wall = 1
    StartPoint = 2
    Treaded = 3
    Backtracked = 4
     */
    File Archivo;
    int[][] Matriz;
    int Start;
    int Xspaces = 0;
    int YSpaces = 0;
    int StartingY = 0;
    int StartingX = 0;
    FileReader FR;
    BufferedReader BR;
    ArrayList<String> stringMaze;
    String Text;
    Stack<Player> Backtrack;
    ArrayList<String> Steps;
    boolean completed = true;

    public Laberinto(File Archivo) {
        stringMaze = new <String>ArrayList();
        Steps = new ArrayList<>();
        try {
            this.FR = new FileReader(Archivo);
            this.BR = new BufferedReader(FR);
            Crear();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("otro");
        }
    }

    public void Crear() {
        int Y = 0;
        String CurrentLine;
        try {
            while ((CurrentLine = BR.readLine()) != null) {
                Text += CurrentLine + "\n";
                stringMaze.add(CurrentLine);
                System.out.println(CurrentLine);
                Xspaces = CurrentLine.length();
                YSpaces++;
            }

            System.out.println("XSpaces: " + Xspaces);
            System.out.println("YSpaces:" + YSpaces);
            LlenarMatriz();
            BR.close();
            FR.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public String GiveString() {
        return Text;
    }

    void Resolver() {
        Player p = new Player(StartingY, StartingX);
        Backtrack = new Stack<>();
        /*System.out.println("p.X: " + p.X);
        System.out.println("p.Y :" + p.Y);
        System.out.println("Starting point: " + Matriz[p.Y][p.X]);*/
        int Choices;
        int i = 0;
        while (completed) {
            //printMatriz();
            //System.out.println("p.X: " + p.X);
            //System.out.println("p.Y :" + p.Y);
            Choices = 0;
            if (CanMoveLeft(p)) {
                Choices++;
            }
            if (CanMoveUp(p)) {
                Choices++;
            }
            if (CanMoveRight(p)) {
                Choices++;
            }
            if (CanMoveDown(p)) {
                Choices++;
            }
            Player p2 = new Player(p.Y, p.X);
            System.out.println(p2.toString());
            Backtrack.push(p2);
            /*for (int j = 0; j < Backtrack.size(); j++) {
                System.out.println(Backtrack.get(j).toString());
            }*/
            System.out.println("Choices: " + Choices);
            int[][] Step = Matriz;
            if (Choices <= 0) {
                /*for (int j = 0; j < Backtrack.size(); j++) {
                    System.out.println(Backtrack.get(j).toString());
                }*/
                System.out.println("Dead End");
                Backtrack.pop();
                p = Backtrack.pop();
                System.out.println(Backtrack.size());
            } else {
                Steps.add(printMatriz(Step));
                Move(p);
            }
            i++;

        }
        System.out.println("Steps size: " + Steps.size());
    }

    public void LlenarMatriz() {
        Matriz = new int[YSpaces][Xspaces];
        for (int i = 0; i < stringMaze.size(); i++) {
            for (int j = 0; j < stringMaze.get(i).length(); j++) {
                switch (stringMaze.get(i).charAt(j)) {
                    case 'H':
                        Matriz[i][j] = 1;
                        break;
                    case ' ':
                        Matriz[i][j] = 0;
                        break;
                    case 'X':
                        Matriz[i][j] = 2;
                        StartingY = i;
                        StartingX = j;
                        break;
                    case 'O':
                        Matriz[i][j] = 4;
                }
            }
        }
        for (int i = 0; i < YSpaces; i++) {
            for (int j = 0; j < Xspaces; j++) {
                System.out.print(Matriz[i][j]);
            }
            System.out.println("");
        }
    }

    public boolean CanMoveLeft(Player p) {
        try {
            if (!((Matriz[p.X - 1][p.Y] == 1) || (Matriz[p.X - 1][p.Y] == 3))) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

    public boolean CanMoveRight(Player p) {
        try {
            //System.out.println("Matriz x+1: "+Matriz[p.X+1][p.Y+1]);
            if (!((Matriz[p.X + 1][p.Y] == 1) || (Matriz[p.X + 1][p.Y] == 3))) {
                return true;
            }
        } catch (Exception e) {
            System.out.println("error in right");
        }
        return false;
    }

    public boolean CanMoveDown(Player p) {
        try {
            System.out.println("Matriz y+1: " + (Matriz[p.X][p.Y + 1]));
            System.out.println("");
            if (!((Matriz[p.X][p.Y + 1] == 1) || (Matriz[p.X][p.Y + 1] == 3))) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

    public boolean CanMoveUp(Player p) {
        try {
            if (!((Matriz[p.X][p.Y - 1] == 1) || (Matriz[p.X][p.Y - 1] == 3))) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }

    public void Move(Player p) {
        int op;
        if (CanMoveUp(p)) {
            if (Matriz[p.X][p.Y - 1] == 4) {
                completed = false;
            } else {
                Matriz[p.X][p.Y - 1] = 3;
                p.Y--;
            }
            //System.out.println("Moved Up");
        } else if (CanMoveRight(p)) {
            if (Matriz[p.X + 1][p.Y] == 4) {
                completed = false;
            }
            Matriz[p.X + 1][p.Y] = 3;
            p.X++;
            System.out.println("Moved Right");
        } else if (CanMoveDown(p)) {
            if (Matriz[p.X][p.Y+1] == 4) {
                completed = false;
            }
            Matriz[p.X][p.Y + 1] = 3;
            p.Y++;
            System.out.println("Moved Down");
        } else if (CanMoveLeft(p)) {
            if (Matriz[p.X-1][p.Y] == 4) {
                completed = false;
            }            
            Matriz[p.X - 1][p.Y] = 3;
            p.X--;
            System.out.println("Moved Left");
        }
        /*if (CanMoveUp(p)) {
            Matriz[p.X][p.Y-1] = 3;
            p.Y--;
            System.out.println("Moved Up");
        } 
        if (CanMoveRight(p)) {
            Matriz[p.X+1][p.Y] = 3;
            p.X++;
            System.out.println("Moved Right");
        }
        if (CanMoveDown(p)) {
            Matriz[p.X][p.Y+1] = 3;
            p.Y++;
            System.out.println("Moved Down");
        }
        if (CanMoveLeft(p)) {
            Matriz[p.X-1][p.Y] = 3;
            p.X--;
            System.out.println("Moved Left");
        }*/
    }

    public String printMatriz(int[][] matriz) {
        String fill = "";
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j]);
                //fill += matriz[i][j];
                switch (matriz[i][j]) {
                    case 0:
                        fill += "0";
                        break;
                    case 1:
                        fill += "1";
                        break;
                    case 2:
                        fill += "2";
                        break;
                    case 3:
                        fill += "3";
                        break;
                    case 4:
                        fill += "4";
                        break;
                }
            }
            fill += "\n";
            System.out.println("");
        }
        return fill;
    }

}
