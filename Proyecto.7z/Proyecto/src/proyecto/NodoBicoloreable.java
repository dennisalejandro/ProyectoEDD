/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.ArrayList;

/**
 *
 * @author denni
 */
public class NodoBicoloreable {
    String Color;
    boolean Visited;
    int ID;
    ArrayList Conexiones;

    public NodoBicoloreable(int ID, String Color, boolean Visited, ArrayList Conexiones) {
        this.Color = Color;
        this.Visited = Visited;
        this.Conexiones = Conexiones;
        this.ID = ID;
    }

    @Override
    public String toString() {
        return ID+" Color: "+Color;
    }
    
    
}
