/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import java.util.ArrayList;

/**
 *
 * @author denni
 */
public class Bicoloreable {
    ArrayList<NodoBicoloreable> ListNodes;

    public Bicoloreable(ArrayList<NodoBicoloreable> ListNodes) {
        this.ListNodes = ListNodes;
    }
    
    public void Visitar(int i, String Color) {
        ListNodes.get(i).Visited = true;
        ListNodes.get(i).Color = Color;
        //System.out.println("Visitando Nodo: "+ListNodes.get(i).ID);
        for (int j = 0;j<ListNodes.get(i).Conexiones.size();j++) {
            if (ListNodes.get((int)ListNodes.get(i).Conexiones.get(j)).Visited==false) {
                if (ListNodes.get(i).Color.equals("Azul")) {
                     Visitar((int)ListNodes.get(i).Conexiones.get(j), "Rojo");
                } else {
                    Visitar((int)ListNodes.get(i).Conexiones.get(j), "Azul");
                }
                
            } else {
                //System.out.println("Nodo: "+ListNodes.get((int)ListNodes.get(i).Conexiones.get(j))+" ya visitado");
            }
        }
    }
    public void Reset() {
    
    }
    public boolean Check() {
        for (int i = 0;i<ListNodes.size();i++) {
            NodoBicoloreable A = ListNodes.get(i);
            for (int j = 0;j<A.Conexiones.size();j++) {
                for (int k = 0;k<ListNodes.size();k++) {
                    if ((int)A.Conexiones.get(j)==ListNodes.get(k).ID) {
                        NodoBicoloreable B = ListNodes.get(k);
                        if (A.Color.equals(B.Color)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
}
