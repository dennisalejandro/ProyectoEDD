/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;

/**
 *
 * @author denni
 */
public class NodoEmpleado extends DefaultMutableTreeNode {

    Empleado Employee;

    public NodoEmpleado(Empleado Employee) {
        this.Employee = Employee;
        this.setUserObject(this.Employee);
        ChildLister();
    }

    private void ChildLister() {
        for (int i = 0; i < Employee.SubEmpleados.size(); i++) {
            add(new NodoEmpleado(this.Employee.SubEmpleados.get(i)));
        }
    }

    public void AddEmployee(Empleado e) {
        Employee.SubEmpleados.add(e);
        add(new NodoEmpleado(e));
    }

    public void Calcular() {
        int Total = 0;
        for (int i = 0; i < getChildCount(); i++) {
            NodoEmpleado Child = (NodoEmpleado) this.children.get(i);
            Empleado emp = (Empleado) Child.getUserObject();
            Total += emp.getDesempeño();
            if (!Child.isLeaf()) {
                Child.Calcular();
            }
        }
        this.Employee.Desempeño = (Total / getChildCount());
    }
    /*Metodo para Agregar al arbol: 
        NodoEmpleado Parent = (NodoEmpleado) jTree1.getLastSelectedPathComponent();
        Empleado e = new Empleado();
        NodoEmpleado Child = new NodoEmpleado(e);
        DefaultTreeModel model = (DefaultTreeModel) jTree1.getModel();
        model.insertNodeInto(Child, Parent, Parent.getChildCount());
    */
    
    
}
