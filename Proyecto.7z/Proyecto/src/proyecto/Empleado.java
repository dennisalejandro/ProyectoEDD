/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

/**
 *
 * @author denni
 */
import java.util.ArrayList;

public class Empleado {

    ArrayList<Empleado> SubEmpleados = new ArrayList<Empleado>();
    double Desempeño;
    boolean isLeaf;
    
    public Empleado(int Desempeño) {
        this.Desempeño = Desempeño;

    }

    public Empleado() {
        Desempeño = 0;
        isLeaf = true;
    }

    public ArrayList<Empleado> getSubEmpleados() {
        return SubEmpleados;
    }

    public void setSubEmpleados(ArrayList<Empleado> SubEmpleados) {
        this.SubEmpleados = SubEmpleados;
        if (!this.SubEmpleados.isEmpty()) {
            isLeaf = false;
        }
    }

    public double getDesempeño() {
        return Desempeño;
    }

    public void setDesempeño(double Desempeño) {
        this.Desempeño = Desempeño;
    }

    public void Calcular() {
        double Total=0;
        for (int i = 0; i < SubEmpleados.size(); i++) {
            Total+=SubEmpleados.get(i).Desempeño;
        }
        System.out.println("Algo");
        //if (!isLeaf) {
            setDesempeño(Total/SubEmpleados.size());
            System.out.println("Otro");
        //}
    }

    @Override
    public String toString() {
        return "Desempeño: " + this.getDesempeño();
    }

}
